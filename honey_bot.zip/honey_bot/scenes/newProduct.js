const { Telegraf, Markup, Extra } = require('telegraf')
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
const TelegrafI18n = require('telegraf-i18n')
const send = require('../util/send');
const User = require("../models/user.js");

const addUser = ({ email, userid, balance = 0, lang}) => {
    const user = new User({
        email,
        userid,
        balance,
        lang,
    });
    user
        .save()
        .catch((err) => console.log(err));
};

module.exports = new WizardScene(
    "newUser",
    async (ctx) => {
        ctx.i18n.locale(ctx.session.lang);
        await send(
            ctx,
            ctx.i18n.t('name_product')
        );
        ctx.session.userid = ctx.chat.id;
        return ctx.wizard.next();
    },
    async (ctx) => {
        await send(
            ctx,
            ctx.i18n.t('price_product')
        );
        ctx.session.nameproduct = ctx.message.text;
        return ctx.wizard.next();
    },
    async (ctx) => {
        await send(
            ctx,
            ctx.i18n.t('description_product')
        );
        ctx.session.priceproduct = ctx.message.text;
        return ctx.wizard.next();
    },
    async (ctx) => {
        ctx.session.descriptionproduct = ctx.message.text;

        addUser(ctx.session);
        ctx.scene.enter("mainMenu");
        return ctx.scene.leave();
    }
);