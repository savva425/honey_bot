
const { Telegraf, Markup, Extra } = require('telegraf')
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
const TelegrafI18n = require('telegraf-i18n')
const send = require('../util/send');

module.exports = new WizardScene(
    "langConf",
    async (ctx) => {
        await send(
            ctx,
            'Select language / Выберите язык',
            Extra.HTML().markup((m) =>
            m.inlineKeyboard([
                [m.callbackButton('English', 'set_en')],
                [m.callbackButton('Русский', 'set_ru')],
            ]))
        );

        return ctx.scene.leave();
    },
);