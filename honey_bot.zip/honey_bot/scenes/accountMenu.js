const { Telegraf, Markup, Extra } = require('telegraf')
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
const TelegrafI18n = require('telegraf-i18n')
const send = require('../util/send');
const User = require("../models/user.js");

module.exports = new WizardScene(
    "accountMenu",
    async (ctx) => {
        ctx.i18n.locale(ctx.session.lang);
        User.findOne({userid: `${ctx.chat.id}`}).exec(function(err, user){
            send(
                ctx,
                ctx.i18n.t('account_text', {user}),
                Extra.HTML().markup((m) =>
                m.inlineKeyboard([
                    [m.callbackButton(ctx.i18n.t('input_pay'), 'input_pay'),
                    m.callbackButton(ctx.i18n.t('output_pay'), 'output_pay')],
                    [m.callbackButton(ctx.i18n.t('back'), 'main_menu')]
                ]))
            );
        })
        return ctx.scene.leave();
    },
);