const { Telegraf, Markup, Extra } = require('telegraf')
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
const TelegrafI18n = require('telegraf-i18n')
const send = require('../util/send');

module.exports = new WizardScene(
    "inputPayMenu",
    async (ctx) => {
        ctx.i18n.locale(ctx.session.lang);
        await send(
            ctx,
            ctx.i18n.t('input_pay_menu_text'),
            Extra.HTML().markup((m) =>
            m.inlineKeyboard([
                [m.callbackButton(ctx.i18n.t('pay_invoice'), 'pay_invoice'),
                m.callbackButton(ctx.i18n.t('paid'), 'paid')],
                [m.callbackButton(ctx.i18n.t('back'), 'main_menu')]
            ]))
        );
        return ctx.scene.leave();
    },
);