const { Telegraf, Markup, Extra } = require('telegraf')
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
const TelegrafI18n = require('telegraf-i18n')
const send = require('../util/send');

module.exports = new WizardScene(
    "mainMenu",
    async (ctx) => {
        ctx.i18n.locale(ctx.session.lang);
        await send(
            ctx,
            ctx.i18n.t('main_text'),
            Extra.HTML().markup((m) =>
            m.inlineKeyboard([
                [m.callbackButton(ctx.i18n.t('main_page'), 'main_page')],
                [m.callbackButton(ctx.i18n.t('categories'), 'categories'),
                m.callbackButton(ctx.i18n.t('account'), 'account')]
            ]))
        );
        return ctx.scene.leave();
    },
);