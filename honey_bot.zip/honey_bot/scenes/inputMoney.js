const { Telegraf, Markup, Extra } = require('telegraf')
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
const TelegrafI18n = require('telegraf-i18n')
const send = require('../util/send');

module.exports = new WizardScene(
    "inputMoney",
    async (ctx) => {
        ctx.i18n.locale(ctx.session.lang);
        await send(
            ctx,
            ctx.i18n.t('input_money')
        );
        return ctx.wizard.next();
    },
    async (ctx) => {
        ctx.session.money = ctx.message.text;
        if (ctx.session.money < 0.01) {
            ctx.session.money = 0.01
        }

        ctx.scene.enter("paidMenu");
        return ctx.scene.leave();
    }
);