const { Telegraf, Markup, Extra } = require('telegraf')
const { CryptoPay, Assets, PaidButtonNames } = require('@foile/crypto-pay-api');
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
const TelegrafI18n = require('telegraf-i18n')
const send = require('../util/send');

require('dotenv').config()
const token = process.env.CRYPTO_TOKEN

const cryptoPay = new CryptoPay(token, { hostname: 'pay.crypt.bot' });

module.exports = new WizardScene(
    "paidMenu",
    async (ctx) => {
        ctx.i18n.locale(ctx.session.lang);
        const invoice = await cryptoPay.createInvoice(Assets.TON, ctx.session.money, {
            description: 'replenishment',
            paid_btn_name: PaidButtonNames.OPEN_BOT,
            paid_btn_url: 'https://t.me/crypto_honey_bot',
          });
        
          ctx.session.invoice_id = invoice.invoice_id;
        
          await send(ctx, 
              invoice.pay_url, 
              Extra.HTML().markup((m) =>
                  m.inlineKeyboard([
                      [m.callbackButton(ctx.i18n.t('paid'), 'paid')],
                      [m.callbackButton(ctx.i18n.t('back'), 'main_menu')]
                  ]))
              );

        return ctx.scene.leave();
    }
);
