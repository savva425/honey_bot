const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    userid: {
        type: Number,
        required: true,
    },
    located: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    price: {
        type: Number,
        required: true,
    },
    pause: {
        type: Boolean,
        default: false,
        required: false,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Product", productSchema);