const { Telegraf, Markup, Extra } = require('telegraf')
const { CryptoPay, Assets, PaidButtonNames } = require('@foile/crypto-pay-api');
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");

const path = require('path');

const TelegrafI18n = require('telegraf-i18n')
const i18n = new TelegrafI18n({
    directory: path.resolve(__dirname, 'locales'),
    defaultLanguage: 'ru',
});

require('dotenv').config()
const token = process.env.CRYPTO_TOKEN
const bot = new Telegraf(process.env.BOT_TOKEN)

const send = require('./util/send');

const mainMenu = require('./scenes/mainMenu');
const newUser = require('./scenes/newUser');
const mainPage = require('./scenes/mainPage');
const langConf = require('./scenes/langConf');
const accountMenu = require('./scenes/accountMenu');
const inputPayMenu = require('./scenes/inputPayMenu');
const inputMoney = require('./scenes/inputMoney');
const paidMenu = require('./scenes/paidMenu');


const mongoose = require("mongoose");
const MONGO_URL = "mongodb://localhost:27017"
const User = require("./models/user.js");

mongoose.connect(MONGO_URL, {});
mongoose.connection.on("connected", () => {
    console.log("db connected");
});
mongoose.connection.on("error", () => console.error("error connecting to db"));


bot.use(i18n.middleware());
bot.use(session());

const stage = new Stage([mainMenu, newUser, langConf, mainPage, accountMenu, inputPayMenu, inputMoney, paidMenu]);
bot.use(stage.middleware());

bot.command('mainMenu', (ctx) => {
    ctx.scene.enter("mainMenu");
});

bot.start(async (ctx) => {
    User.findOne({userid: `${ctx.chat.id}`}).exec(function(err, user){
        if(!user) {
            ctx.scene.enter("langConf");
        }
        else {
            if(user.lang == 'ru') {
                ctx.session.lang = 'ru';
            }
            else {
                ctx.session.lang = 'en';
            }

            ctx.scene.enter("mainMenu");
        }
    });
});

bot.action('account', (ctx) => {
    ctx.scene.enter("accountMenu");
})


bot.action('input_pay', (ctx) => {
    ctx.scene.enter("inputPayMenu");
})
/*
bot.action('output_pay', (ctx) => {
    ctx.scene.enter("outputPayMenu");
})*/
const cryptoPay = new CryptoPay(token, { hostname: 'pay.crypt.bot' });

bot.action('pay_invoice', async (ctx) => {
    await ctx.scene.enter("inputMoney");
})
bot.action('paid', async (ctx) => {
    cryptoPay.getInvoices(options = {status : 'paid'}).then(function(result) {
        if(result.items[0].invoice_id == ctx.session.invoice_id) {
            User.findOne({userid: `${ctx.chat.id}`}).exec(function(err, user){
                user.balance = parseFloat(user.balance) + parseFloat(ctx.session.money);
                user.save();
            })
            ctx.scene.enter("mainMenu");
        }
    })
})


bot.action('main_page', (ctx) => {
    ctx.scene.enter("mainPage");
})
bot.action('main_menu', (ctx) => {
    ctx.scene.enter("mainMenu");
})
bot.action('set_en', (ctx) => {
    ctx.session.lang = 'en';
    ctx.scene.enter("newUser");
})
bot.action('set_ru', (ctx) => {
    ctx.session.lang = 'ru';
    ctx.scene.enter("newUser");
})



bot.launch()

process.once('SIGINT', () => bot.stop('SIGINT'))
process.once('SIGTERM', () => bot.stop('SIGTERM'))