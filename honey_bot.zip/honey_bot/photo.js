const { Telegraf } = require("telegraf");
const WizardScene = require("telegraf/scenes/wizard");
const Stage = require("telegraf/stage");
const session = require("telegraf/session");
require('dotenv').config()
const axios = require("axios");

var tmp;

const bot = new Telegraf(process.env.BOT_TOKEN)
bot.use(session());

const newUserWizard = new WizardScene(
    "newUser",
    async (ctx) => {
        await ctx.replyWithMarkdown(
        "*Please enter the email you want to be notified to*"
        );
        return ctx.wizard.next();
    },
    async (ctx) => {
        tmp = ctx.update.message.photo;
        bot.telegram.sendMessage(ctx.chat.id, `${ctx.message.text}`, {
        reply_markup: {
            inline_keyboard: [
            [{ text: "Add a Product", callback_data: "addProductBtn" }],
            [{ text: "BOT's Manual page", callback_data: "helpBtn" }],
            ],
        },
        });
        return ctx.scene.leave();
    }
);

const stage = new Stage([newUserWizard]);
bot.use(stage.middleware());

bot.start(async (ctx) => {
    ctx.scene.enter("newUser");
});

bot.command('test', (ctx) => {
    console.log(tmp[1].file_id);
    try {
        console.log(ctx.telegram.getFileLink (tmp[0].file_id) .then ((link) => {console.log (link);}));
    } catch (e) {

    }
});

bot.launch()
